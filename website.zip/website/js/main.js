(function () {
  const header = document.getElementById("header");
  const menuToggle = document.getElementById("menuToggle");
  const navMobile = document.getElementById("navMobile");

  function onScroll() {
    if (window.scrollY > 8) {
      header.classList.add("scrolled");
    } else {
      header.classList.remove("scrolled");
    }
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  if (menuToggle && navMobile) {
    menuToggle.addEventListener("click", function () {
      const open = navMobile.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(open));
    });

    navMobile.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        navMobile.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
      });
    });
  }
})();
