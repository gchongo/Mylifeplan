# Meridian Plan 宣传站点

产品宣传首页，静态 HTML/CSS/JS，保存在本地 `website/` 目录（不纳入主项目 Git 仓库）。

## 目录结构

```
website/
  index.html
  css/style.css
  js/main.js
  nginx.conf.example
```

## 本地预览

```bash
cd website
python -m http.server 8080
```

浏览器打开 http://localhost:8080

## 部署说明

1. 将 `website/` 内全部文件上传到 VPS 静态站点目录（如 `/var/www/meridian-marketing`）。
2. 参考 `nginx.conf.example` 配置 Nginx，将 `server_name` 与 `root` 改为你的域名与路径。
3. 页面内登录/注册链接使用相对路径（`/login`、`/register`）。若应用部署在独立域名，请在 `index.html` 中替换为实际地址，或通过 Nginx 反代到同一域名。

应用本体部署见主项目 `docs/deploy-vps.md`。

## 更新

修改本地文件后，重新上传至服务器即可，无需与主应用构建流程合并。
